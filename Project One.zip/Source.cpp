/*
* Matthew Smith
* Project One
* CS-210
*/

#include <iostream>
using namespace std;

// declaring 24 hour time class
class Time24Hour;

// declaring enum for AM and PM on 12 hour clock
enum AMPM {
	AM, PM
}ampm;

// parent time class to 12 and 24 hour time classes
class Time { 
public:
	int hour;
	int minute;
	int second;
	virtual void addHour() = 0;
	virtual void addMinute() = 0;
	virtual void addSecond() = 0;
};

// 12 hour time inherits from time class
class Time12Hour : public Time {

// methods for 12 hour class
public: Time12Hour(int H, int M, int S) {
	hour = H;
	minute = M;
	second = S;
	ampm = AM;
}
	  void addHour() {
		  if (hour == 11) {
			  hour = 12;
			  ampm = ampm == AM ? PM : AM;
		  }
		  else if (hour == 12) {
			  hour = 1;
		  }
		  else {
			  hour += 1;
		  }
	  }

	  void addMinute() {
		  if (minute == 59) {
			  minute = 0;
			  addHour();
		  }
		  else {
			  minute += 1;
		  }
	  }

	  void addSecond() {
		  if (second == 59) {
			  second = 0;
			  addMinute();
		  }
		  else {
			  second += 1;
		  }
	  }

	  friend void displayTime(const Time12Hour&, const Time24Hour&);
};


// 24 hour time inherets from time class
class Time24Hour : public Time {

// methods for 24 hour class
public: Time24Hour(int H, int M, int S) {
	hour = H;
	minute = M;
	second = S;
}
	  // methods to change time on both clocks
	  void addHour() {
		  if (hour == 23) {
			  hour = 0;
		  }
		  else {
			  hour += 1;
		  }
	  }

	  void addMinute() {
		  if (minute == 59) {
			  minute = 0;
			  addHour();
		  }
		  else {
			  minute += 1;
		  }
	  }

	  void addSecond() {
		  if (second == 59) {
			  second = 0;
			  addMinute();
		  }
		  else {
			  second += 1;
		  }
	  }


	  friend void displayTime(const Time12Hour&, const Time24Hour&);
};


void displayTime(const Time12Hour& time12, const Time24Hour& time24) {

	cout << "************************** ***************************" << endl;
	cout << "*     12-Hour Clock      * *      24-Hour Clock      *" << endl;
	cout << "*      ";
	// if statements to add 0 before numbers less than 10
	if (time12.hour < 10)
		cout << "0";
	cout << time12.hour << ":";
	if (time12.minute < 10)
		cout << "0";
	cout << time12.minute << ":";
	if (time12.second < 10)
		cout << "0";
	cout << time12.second;
	if (ampm == AM)
		cout << " AM       * *        ";
	else {
		cout << " PM       * *        ";
	}
	if (time24.hour < 10)
		cout << "0";
	cout << time24.hour << ":";
	if (time24.minute < 10)
		cout << "0";
	cout << time24.minute << ":";
	if (time24.second < 10)
		cout << "0";
	cout << time24.second;
	cout << "         *\n";
	cout << "************************** ***************************" << endl;
}

// Main function with choice selection and input validation using switch
int main() {
	Time12Hour hour12_Clock(12, 0, 0);
	Time24Hour hour24_Clock(0, 0, 0);
	displayTime(hour12_Clock, hour24_Clock);

	// Menu loop
	while (true) {
		cout << "***************************" << endl;
		cout << "* 1 - Add One Hour        *" << endl;
		cout << "* 2 - Add One Minute      *" << endl;
		cout << "* 3 - Add One Second      *" << endl;
		cout << "* 4 - Exit Program        *" << endl;
		cout << "***************************" << endl;
		int userChoice;
		cin >> userChoice;
		switch (userChoice) {
		case 1:
			hour12_Clock.addHour();
			hour24_Clock.addHour();
			displayTime(hour12_Clock, hour24_Clock);
			break;
		case 2:
			hour12_Clock.addMinute();
			hour24_Clock.addMinute();
			displayTime(hour12_Clock, hour24_Clock);
			break;
		case 3:
			hour12_Clock.addSecond();
			hour24_Clock.addSecond();
			displayTime(hour12_Clock, hour24_Clock);
			break;
		case 4:
			cout << "Good Bye!";
			exit(1);
			break;
		default:
			cout << "Invalid selection!\n";
			break;
		}
	}
}